TOKEN = '7098669318:AAGhkyUKn9kJV3cqVXLX3vVBdAzcqt7DqKk'
keys = {
    'евро': 'EUR',
    'доллар': 'USD',
    'рубль': 'RUB',
}